<?php

function checkwork()
{
    echo '<script language="javascript">';
    echo 'alert("message successfully sent")';
    echo '</script>';
}
